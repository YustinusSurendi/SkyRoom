import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:sky_room/firebase_auth/auth.dart';
import 'package:sky_room/providers/providerLogin.dart';
import 'package:sky_room/screen/loginScreen.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sky_room/screen/userProfileWidget.dart';

class MyBio extends StatefulWidget {
  const MyBio({Key? key}) : super(key: key);

  @override
  State<MyBio> createState() => _MyBioState();
}

class _MyBioState extends State<MyBio> {
  late AuthFirebase auth;
  late String uid;
  late Map<String, dynamic> userData = {};
  File? _image;
  final picker = ImagePicker();
  final currentUser = FirebaseAuth.instance.currentUser!;
  final usersCollection = FirebaseFirestore.instance.collection("users");

  @override
  void initState() {
    super.initState();
    uid = context.read<UserProvider>().uid ?? "";
    _readData();
  }

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      await _uploadData();
    } else {
      print('User canceled image picking');
    }
  }

  Future<void> _showImagePickerOptions() async {
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.camera),
              title: const Text('Camera'),
              onTap: () async {
                Navigator.pop(context);
                await _checkCameraPermissionAndPickImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _checkCameraPermissionAndPickImage() async {
    PermissionStatus status = await Permission.camera.request();

    if (status == PermissionStatus.granted) {
      await _pickImage(ImageSource.camera);
    } else {
      print('Camera permission denied');
    }
  }

  Future<void> _readData() async {
    try {
      DocumentSnapshot userSnapshot =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();

      if (userSnapshot.exists) {
        setState(() {
          userData = userSnapshot.data() as Map<String, dynamic>;
        });
      } else {
        print('User data not found.');
      }
    } catch (error) {
      print('Error fetching user data: $error');
    }
  }

  Future<void> _deleteProfilePicture() async {
    await Firebase.initializeApp();

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({'profilefoto': null});
  }

  Future<void> _uploadData() async {
    if (_image == null) return;

    try {
      final Reference storageReference = FirebaseStorage.instance.ref().child(
          'userfotoprofile/${DateTime.now().millisecondsSinceEpoch}.jpg');
      await storageReference.putFile(_image!);

      final downloadURL = await storageReference.getDownloadURL();

      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'profilefoto': downloadURL,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('profile image uploaded successfully'),
        ),
      );
    } catch (e) {
      print('Error uploading image: $e');
    }
  }

  Future<void> editField(String field) async {
    String newValue = "";
    await showDialog(
      barrierDismissible: true,
      context: context,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(
            sigmaX: 5.0,
            sigmaY: 5.0), // Adjust sigmaX and sigmaY for blur intensity
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          title: Text(
            'Edit your $field',
            style: const TextStyle(color: Colors.white),
          ),
          content: TextField(
            autofocus: true,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Enter new $field',
              hintStyle: TextStyle(color: Colors.grey),
            ),
            onChanged: (value) {
              newValue = value;
            },
          ),
          actions: [
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    child: Text(
                      'Cancel',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  TextButton(
                    child: Text(
                      'Save',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () => Navigator.of(context).pop(newValue),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );

    if (newValue.trim().isNotEmpty) {
      await usersCollection.doc(currentUser!.uid).update({field: newValue});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: const Text(
            "Profile",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance
                .collection("users")
                .doc(currentUser.uid)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                final userData = snapshot.data!.data() as Map<String, dynamic>;

                return ListView(
                  children: [
                    Column(children: [
                      const Center(
                        child: CircleAvatar(
                          backgroundColor: Color.fromARGB(255, 121, 121, 121),
                          radius: 100,
                          child: Icon(
                            Icons.person,
                            size: 150,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    Color.fromARGB(255, 124, 124, 124),
                              ),
                              onPressed: () {},
                              child: Text(
                                'Upload',
                                style: TextStyle(
                                    fontSize: 20, color: Colors.white),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    Color.fromARGB(255, 124, 124, 124),
                              ),
                              onPressed: () {},
                              child: Icon(
                                Icons.delete,
                                color: Colors.white,
                              ),
                            ),
                          )
                        ],
                      ),
                      MyTextBoxUserName(
                        sectionText: userData['username'],
                        sectionName: 'username',
                        onpressed: () => editField('username'),
                      ),
                      MyTextBoxEmail(
                        sectionText: userData['email'],
                        sectionName: 'email',
                      ),
                      Center(
                        child: Container(
                          width: 150,
                          height: 50,
                          margin: const EdgeInsets.only(top: 100),
                          child: ElevatedButton(
                            onPressed: () {
                              setState(() {
                                AuthFirebase().signOut().then((result) {
                                  if (result == null) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const LoginScreen()));
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content: Text('Berhasil Sign Out'),
                                      backgroundColor: Colors.green,
                                    ));
                                  } else {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content: Text(
                                        'Berhasil Keluar',
                                        style: TextStyle(fontSize: 16),
                                      ),
                                      backgroundColor: Colors.green,
                                    ));
                                  }
                                });
                              });
                            },
                            style: ElevatedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                backgroundColor: Colors.red),
                            child: const Text(
                              'Logout',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                          ),
                        ),
                      ),
                    ])
                  ],
                );
              } else if (snapshot.hasError) {
                return Center(
                  child: Text('Error ${snapshot.error}'),
                );
              }

              return const Center(
                child: CircularProgressIndicator(),
              );
            }));
  }
}
