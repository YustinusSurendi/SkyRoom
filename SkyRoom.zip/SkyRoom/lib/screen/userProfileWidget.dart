import 'package:flutter/material.dart';

class MyTextBoxUserName extends StatelessWidget {
  final String sectionName;
  final String sectionText;
  final void Function()? onpressed;
  const MyTextBoxUserName({
    super.key,
    required this.sectionName,
    required this.sectionText,
    required this.onpressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.white,
            width: 1.0,
          ),
        ),
      ),
      padding: EdgeInsets.only(
        left: 15,
        bottom: 15,
      ),
      margin: EdgeInsets.only(left: 20, right: 20, top: 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(sectionName, style: TextStyle(color: Colors.grey)),
              IconButton(
                onPressed: onpressed,
                icon: Icon(Icons.edit),
                color: Colors.grey,
              )
            ],
          ),
          Text(sectionText, style: TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}

class MyTextBoxEmail extends StatelessWidget {
  final String sectionName;
  final String sectionText;
  const MyTextBoxEmail({
    super.key,
    required this.sectionName,
    required this.sectionText,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.white,
            width: 1.0,
          ),
        ),
      ),
      padding: EdgeInsets.only(
        left: 15,
        bottom: 15,
      ),
      margin: EdgeInsets.only(left: 20, right: 20, top: 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(sectionName, style: TextStyle(color: Colors.grey)),
              Icon(
                Icons.email_outlined,
                color: Colors.grey,
              )
            ],
          ),
          Text(sectionText, style: TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}
