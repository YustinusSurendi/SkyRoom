import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sky_room/model/modelUsers.dart' as my_user;

class AuthFirebase {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Future<String?> signUp(String email, String password) async {
    UserCredential authResult = await _firebaseAuth
        .createUserWithEmailAndPassword(email: email, password: password);
    User? user = authResult.user;
    return user?.uid;
  }

  Future<String?> login(String email, String password) async {
    try {
      UserCredential authResult = await _firebaseAuth
          .signInWithEmailAndPassword(email: email, password: password);
      User? user = authResult.user;
      return user?.uid;
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future<User?> getUser() async {
    User? user = _firebaseAuth.currentUser;
    return user;
  }

  Future signOut() async {
    await _firebaseAuth.signOut();
    print("Sign Out");
  }

  Future<void> addDataUser( String userId, String email, String username) async {
    CollectionReference userData =
        FirebaseFirestore.instance.collection('users');

    my_user.ModelUsers newUser =
        my_user.ModelUsers(userId: userId, email: email, username: username);
    await userData.doc(userId).set(newUser.toMap());
  }

  Future<my_user.ModelUsers?> getDataUser(String userId) async {
    CollectionReference userData =
        FirebaseFirestore.instance.collection('users');

    DocumentSnapshot docSnap = await userData.doc(userId).get();

    if (docSnap.exists) {
      return my_user.ModelUsers.fromMap(docSnap.data() as Map<String, dynamic>);
    } else {
      return null;
    }
  }
}
