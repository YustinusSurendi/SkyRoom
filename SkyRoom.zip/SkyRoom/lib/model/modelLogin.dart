class ModelUser {
  final String email;
  final String password;

  ModelUser({
    required this.email,
    required this.password,
  });
}
