class ModelJadwal {
  final String email;
  final String gambar;
  final String room_hotel;
  final String date;

  ModelJadwal({
    required this.email,
    required this.gambar,
    required this.room_hotel,
    required this.date,
  });
}
