class ModelUsers {
  final String userId;
  final String email;
  final String username;

  ModelUsers(
      {required this.userId, required this.email, required this.username});

  factory ModelUsers.fromMap(Map<String, dynamic> map) {
    return ModelUsers(
        userId: map['userId'], email: map['email'], username: map['username']);
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'email': email,
      'username': username,
    };
  }
}
