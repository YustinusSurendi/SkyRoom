List fasilitasList = [
  {'nama': 'AC', 'gambar': 'assets/images/fasilitas_hotel/AC.png'},
  {
    'nama': 'Bathroom',
    'gambar': 'assets/images/fasilitas_hotel/kamar_mandi.png'
  },
  {
    'nama': 'Auto Key',
    'gambar': 'assets/images/fasilitas_hotel/Kunci_otomatis.png'
  },
  {'nama': 'TV', 'gambar': 'assets/images/fasilitas_hotel/Televisi.png'},
  {'nama': 'Wi-Fi', 'gambar': 'assets/images/fasilitas_hotel/WiFi.png'},
  {
    'nama': 'Resepsionis 24 Jam',
    'gambar': 'assets/images/fasilitas_hotel/resepsionis.jpg'
  },
  {
    'nama': 'House Keeping',
    'gambar': 'assets/images/fasilitas_hotel/housekeeping.jpg'
  },
  {
    'nama': 'Free Breakfast',
    'gambar': 'assets/images/fasilitas_hotel/freebreakfast.jpg'
  },
];
