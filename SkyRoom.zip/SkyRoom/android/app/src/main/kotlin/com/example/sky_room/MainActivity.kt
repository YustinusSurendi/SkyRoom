package com.example.sky_room

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
