List fasilitasList = [
  {'nama': 'AC', 'gambar': 'assets/images/fasilitas_hotel/AC.png'},
  {
    'nama': 'Bathroom',
    'gambar': 'assets/images/fasilitas_hotel/kamar_mandi.png'
  },
  {
    'nama': 'Auto Key',
    'gambar': 'assets/images/fasilitas_hotel/Kunci_otomatis.png'
  },
  {'nama': 'TV', 'gambar': 'assets/images/fasilitas_hotel/Televisi.png'},
  {'nama': 'Wi-Fi', 'gambar': 'assets/images/fasilitas_hotel/WiFi.png'},
  {
    'nama': 'Resepsionis 24 Jam',
    'gambar': 'assets/images/fasilitas_hotel/resepsionis.jpg'
  },
  {
    'nama': 'House Keeping',
    'gambar': 'assets/images/fasilitas_hotel/housekeeping.jpg'
  },
  {
    'nama': 'Free Breakfast',
    'gambar': 'assets/images/fasilitas_hotel/freebreakfast.jpg'
  },
];
List roomList = [
  {
    'gambar': 'assets/images/room_hotel/hotel 1.jpg',
    'desc':
        'Hotel 1 adalah hotel yang menawarkan desain yang mewah, elegan dan sangat berkelas buat Anda yang ingin suasana yang mewah, hotel ini memberikan perlengkapan yang terbaik sehingga kualitas hotel ini dijamin bagus buat Anda yang ingin suasana yang mewah dan berkelas. Hotel 1 juga memberikan harga yang terbaik tanpa harus mengeluarkan biaya yang banyak serta di jamin memberikan pengalaman yang terbaik',
    'nama': 'Hotel 01',
    'harga': '300000',
  },
  {
    'gambar': 'assets/images/room_hotel/hotel 2.jpg',
    'desc':
        'Hotel 2 adalah hotel yang menawarkan desain yang polos, elegan dan sangat nyaman buat Anda yang ingin suasana yang tenang, hotel ini memberikan perlengkapan yang terbaik sehingga kualitas hotel ini tidak diragukan lagi buat yang ingin suasana yg tenang. Hotel 2 juga memberikan harga yang terbaik tanpa harus mengeluarkan biaya yang banyak serta di jamin memberikan pengalaman yang terbaik',
    'nama': 'Hotel 02',
    'harga': '350000',
  },
  {
    'gambar': 'assets/images/room_hotel/hotel 3.jpg',
    'desc':
        'Hotel 3 adalah hotel yang menawarkan desain yang elegan dan sangat nyaman buat Anda, dengan perlengkapan yang terbaik sehingga kualitas hotel ini dapat rekomendasi di kunjungi bersama keluarga. Hotel 3 juga memberikan harga yang terbaik tanpa harus mengeluarkan biaya yang banyak serta di jamin memberikan pengalaman yang terbaik',
    'nama': 'Hotel 03',
    'harga': '350000',
  },
  {
    'gambar': 'assets/images/room_hotel/hotel 4.jpg',
    'desc':
        'Hotel 4 adalah hotel yang menawarkan desain yang mewah dan nyaman untuk beristirahat setelah bekerja keras dengan perlengkapan yang terbaik dijamin gak mau pulang. Hotel 4 juga memberikanharga yang terbaik tanpa harus mengeluarkan biaya yang banyak',
    'nama': 'Hotel 04',
    'harga': '300000',
  },
];
