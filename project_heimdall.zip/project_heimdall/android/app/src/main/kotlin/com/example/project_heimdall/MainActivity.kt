package com.example.project_heimdall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
